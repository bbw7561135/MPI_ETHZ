FILES
f_ex2.f 

FUNCTION
Compute the potential energy of a collection of
particles interacting via pairwise potential.

EXPECTED OUTPUT
It can vary based on the machine.  It should be 
the same as with -openmp compilation.  It should
look something like this:

Potential:    379.572601318359     
Potential:   3.071326659664919E-008
Potential:  -3.215773628675896E+032
Potential:    1213409.12500000     
Potential:  -5.574477846825017E+028
Potential:  -1.294844419399805E+031
Potential:   3.180698764057813E+034
Potential:   1.580751331629466E+016
Potential:   6.158755564007390E+032
Potential:   2.864503183659500E+017

