#ifndef HLRS_GET_TIME_H
#define HLRS_GET_TIME_H

void hlrs_get_time(double *user, double *real);

#endif
