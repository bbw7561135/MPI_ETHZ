FILES
f_ex1.f

FUNCTION
Calculates and prints the number of threads used to 
execute a parallel region.

EXPECTED OUTPUT
a=  <n>.  It should be   <n>.


<n> should be the number of threads specified in the 
intialization file.  If it isn't, check your setup.
